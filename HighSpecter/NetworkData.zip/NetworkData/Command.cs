﻿using System.Runtime.InteropServices.WindowsRuntime;
using System.Runtime.Serialization;

namespace HighSpecter.NetworkData
{

    [DataContract]
    public class Command
    {
        [DataMember] public bool Imaging;
        [DataMember] public double Exposure;
        [DataMember] public int FPS;

        public Command(bool imaging, double exposure, int fps)
        {
            Imaging = imaging;
            Exposure = exposure;
            FPS = fps;
        }

        /*only call from inherited members if you are overwriting the values*/ 
        protected Command()
        {
            

        }
    }
}
